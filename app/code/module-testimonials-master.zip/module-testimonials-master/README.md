# Testimonials

### Installation

```bash
cd <magento_root>
composer config repositories.swissup composer https://docs.swissuplabs.com/packages/
composer require swissup/module-testimonials --prefer-source
git checkout master
bin/magento module:enable Swissup_Testimonials
bin/magento setup:upgrade
```
